import connexion
import six

from swagger_server.models.all_report import AllReport  # noqa: E501
from swagger_server.models.report import Report  # noqa: E501
from swagger_server import util


def delete_recipe_report(nutritionist_id, report_id):  # noqa: E501
    """delete recipe report

    &lt;ΛΑ-9&gt;   Ο διατροφολόγος πρέπει να μπορεί να βλέπει τις αναφορές που γίνονται από τους χρήστες στις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that delete the recipe report
    :type nutritionist_id: int
    :param report_id: The ID of the recipe report that is being deleted.
    :type report_id: int

    :rtype: None
    """
    return 'do some magic!'


def get_recipe_report(nutritionist_id, report_id):  # noqa: E501
    """Get recipe report

    &lt;ΛΑ-9&gt;   Ο διατροφολόγος πρέπει να μπορεί να βλέπει τις αναφορές που γίνονται από τους χρήστες στις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that see the recipe report
    :type nutritionist_id: int
    :param report_id: The ID of the recipe report.
    :type report_id: int

    :rtype: Report
    """
    return 'do some magic!'


def get_recipe_reports(nutritionist_id):  # noqa: E501
    """Get recipe reports

    &lt;ΛΑ-9&gt;   Ο διατροφολόγος πρέπει να μπορεί να βλέπει τις αναφορές που γίνονται από τους χρήστες στις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that see the recipe reports
    :type nutritionist_id: int

    :rtype: AllReport
    """
    return 'do some magic!'


def update_recipe_report(nutritionist_id, report_id, day_diet_program_ids=None):  # noqa: E501
    """Update/Correct recipe report

    &lt;ΛΑ-9&gt;   Ο διατροφολόγος πρέπει να μπορεί να βλέπει τις αναφορές που γίνονται από τους χρήστες στις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that update the recipe report
    :type nutritionist_id: int
    :param report_id: The ID of the recipe report that is being updated.
    :type report_id: int
    :param day_diet_program_ids: The Diet Program Details
    :type day_diet_program_ids: List[]

    :rtype: None
    """
    return 'do some magic!'
