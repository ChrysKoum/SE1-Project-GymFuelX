import connexion
import six

from swagger_server.models.recipe import Recipe  # noqa: E501
from swagger_server import util


def add_recipe(nutritionist_id, recipe_type, img_recipe, instructions, ingredients_name, nutritional_table, ingredients_quantity, time, difficulty, servings):  # noqa: E501
    """Add a new recipe

    &lt;ΛΑ-8&gt;   Ο διατροφολόγος πρέπει να μπορεί να διαχειρίζεται τις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist&#x27;s ID
    :type nutritionist_id: int
    :param recipe_type: The recipe type
    :type recipe_type: str
    :param img_recipe: The image of the recipe
    :type img_recipe: str
    :param instructions: The instructions of the recipe
    :type instructions: List[str]
    :param ingredients_name: The ingredients name of the recipe.
    :type ingredients_name: List[str]
    :param nutritional_table: The NutritionalTable of the recipe.
    :type nutritional_table: List[str]
    :param ingredients_quantity: The IngredientsQuantity of the recipe.
    :type ingredients_quantity: List[str]
    :param time: The time that will be needed for the recipe to  be completed.
    :type time: int
    :param difficulty: The difficulty of the recipe.
    :type difficulty: str
    :param servings: The servings that the recipe can produce.
    :type servings: str

    :rtype: Recipe
    """
    return 'do some magic!'


def delete_recipe(nutritionist_id, recipe_id):  # noqa: E501
    """Delete recipe

    &lt;ΛΑ-9&gt;   Ο διατροφολόγος πρέπει να μπορεί να βλέπει τις αναφορές που γίνονται από τους χρήστες στις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that delete the recipe
    :type nutritionist_id: int
    :param recipe_id: The ID of the recipe that is being deleted.
    :type recipe_id: int

    :rtype: None
    """
    return 'do some magic!'


def get_recipe_nutrionist(nutritionist_id, recipe_id):  # noqa: E501
    """Get recipe

    &lt;ΛΑ-8&gt;   Ο διατροφολόγος πρέπει να μπορεί να διαχειρίζεται τις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that see the recipe.
    :type nutritionist_id: int
    :param recipe_id: The ID of the recipe .
    :type recipe_id: int

    :rtype: Recipe
    """
    return 'do some magic!'


def update_recipe_nutritionist(nutritionist_id, recipe_id, recipe_type=None, img_recipe=None, instructions=None, ingredients_name=None, nutritional_table=None, ingredients_quantity=None, time=None, difficulty=None, servings=None):  # noqa: E501
    """Update/Correct recipe

    &lt;ΛΑ-8&gt;   Ο διατροφολόγος πρέπει να μπορεί να διαχειρίζεται τις συνταγές.  # noqa: E501

    :param nutritionist_id: The nutritionist ID that update the recipe report
    :type nutritionist_id: int
    :param recipe_id: The ID of the recipe that is being updated.
    :type recipe_id: int
    :param recipe_type: The recipe type
    :type recipe_type: str
    :param img_recipe: The image of the recipe
    :type img_recipe: str
    :param instructions: The instructions of the recipe
    :type instructions: List[str]
    :param ingredients_name: The ingredients Name of the recipe.
    :type ingredients_name: List[str]
    :param nutritional_table: The NutritionalTable of the recipe.
    :type nutritional_table: List[str]
    :param ingredients_quantity: The IngredientsQuantity of the recipe.
    :type ingredients_quantity: List[str]
    :param time: The time that will be needed for the recipe to  be completed.
    :type time: int
    :param difficulty: The difficulty of the recipe.
    :type difficulty: str
    :param servings: The servings that the recipe can produce.
    :type servings: str

    :rtype: None
    """
    return 'do some magic!'
