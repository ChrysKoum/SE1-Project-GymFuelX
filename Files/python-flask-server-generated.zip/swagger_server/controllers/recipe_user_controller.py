import connexion
import six

from swagger_server.models.all_recipe import AllRecipe  # noqa: E501
from swagger_server.models.recipe import Recipe  # noqa: E501
from swagger_server import util


def get_all_recipies(user_id):  # noqa: E501
    """Get the list of all the Recipies

    &lt;ΛΑ-1&gt;   O χρήστης πρέπει να μπορεί να αναζητά συνταγές και προγράμματα γυμναστικής  # noqa: E501

    :param user_id: the user&#x27;s ID
    :type user_id: int

    :rtype: AllRecipe
    """
    return 'do some magic!'


def get_recipe(user_id, recipe_id):  # noqa: E501
    """Get a specific recipe&#x27;s details

    &lt;ΛΑ-3&gt;   O χρήστης πρέπει να μπορεί να δει τις θρεπτικές λεπτομέρειες για κάθε συνταγή  # noqa: E501

    :param user_id: the user&#x27;s ID
    :type user_id: int
    :param recipe_id: The ID of the recipe
    :type recipe_id: int

    :rtype: Recipe
    """
    return 'do some magic!'
