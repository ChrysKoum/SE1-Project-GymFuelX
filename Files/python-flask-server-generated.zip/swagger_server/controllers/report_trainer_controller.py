import connexion
import six

from swagger_server.models.all_report import AllReport  # noqa: E501
from swagger_server.models.report import Report  # noqa: E501
from swagger_server import util


def delete_report(trainer_id, report_id):  # noqa: E501
    """Get gym program reports

    &lt;ΛΑ-7&gt;   Ο γυμναστής θα πρέπει να έχει την δυνατότητα να βλέπει και να διορθώνει τα προγράμματα γυμναστικής από τυχόν λάθη  # noqa: E501

    :param trainer_id: The trainer ID that deletes the gym program
    :type trainer_id: int
    :param report_id: The ID of the report that is being deleted.
    :type report_id: int

    :rtype: None
    """
    return 'do some magic!'


def get_gym_program_report(trainer_id, report_id):  # noqa: E501
    """Get gym program report

    &lt;ΛΑ-7&gt;   Ο γυμναστής θα πρέπει να έχει την δυνατότητα να βλέπει και να διορθώνει τα προγράμματα γυμναστικής από τυχόν λάθη  # noqa: E501

    :param trainer_id: The trainer ID
    :type trainer_id: int
    :param report_id: The report ID
    :type report_id: int

    :rtype: Report
    """
    return 'do some magic!'


def get_gym_program_reports(trainer_id):  # noqa: E501
    """Get gym program reports

    &lt;ΛΑ-7&gt;   Ο γυμναστής θα πρέπει να έχει την δυνατότητα να βλέπει και να διορθώνει τα προγράμματα γυμναστικής από τυχόν λάθη  # noqa: E501

    :param trainer_id: The trainer Id
    :type trainer_id: str

    :rtype: AllReport
    """
    return 'do some magic!'


def update_report(trainer_id, report_id, gym_program_details):  # noqa: E501
    """Update/Correct fitness program report

    &lt;ΛΑ-7&gt;   Ο γυμναστής θα πρέπει να έχει την δυνατότητα να βλέπει και να διορθώνει τα προγράμματα γυμναστικής από τυχόν λάθη  # noqa: E501

    :param trainer_id: The trainer
    :type trainer_id: int
    :param report_id: The report ID
    :type report_id: int
    :param gym_program_details: The Gym Program Details
    :type gym_program_details: List[str]

    :rtype: None
    """
    return 'do some magic!'
