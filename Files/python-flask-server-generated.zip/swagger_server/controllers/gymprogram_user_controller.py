import connexion
import six

from swagger_server.models.gym_program import GymProgram  # noqa: E501
from swagger_server import util


def get_gym_program(user_id):  # noqa: E501
    """Get a customized gym program

    &lt;ΛΑ-2&gt;   Ο χρήστης πρέπει να μπορεί να λαμβάνει προγράμματα γυμναστικής και πρόγραμμα διατροφής βασισμένα σε προσωπικές πληροφορίες.  # noqa: E501

    :param user_id: the user&#x27;s ID
    :type user_id: int

    :rtype: GymProgram
    """
    return 'do some magic!'
