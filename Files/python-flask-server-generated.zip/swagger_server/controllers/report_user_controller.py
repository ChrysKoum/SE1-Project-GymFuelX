import connexion
import six

from swagger_server import util


def create_diet_report(user_id, recipe_id):  # noqa: E501
    """Create a report to this recipe

    &lt;ΛΑ-5&gt; Ο χρήστης θα πρέπει να μπορεί να κάνει αναφορά σε συνταγές για τυχόν λάθη  # noqa: E501

    :param user_id: the User&#x27;s ID
    :type user_id: int
    :param recipe_id: the recipe&#x27;s ID
    :type recipe_id: int

    :rtype: None
    """
    return 'do some magic!'


def create_gym_report(user_id):  # noqa: E501
    """Create a report to this gymprogram

    &lt;ΛΑ-6&gt; Ο χρήστης θα πρέπει να μπορεί να κάνει αναφορά σε προγράμματα γυμναστικής για τυχόν λάθη ή δυσαρέσκεια.  # noqa: E501

    :param user_id: the User&#x27;s ID
    :type user_id: int

    :rtype: None
    """
    return 'do some magic!'
