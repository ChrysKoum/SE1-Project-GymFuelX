import connexion
import six

from swagger_server.models.diet_program import DietProgram  # noqa: E501
from swagger_server import util


def get_diet_program(user_id):  # noqa: E501
    """Get user&#x27;s diet program

    &lt;ΛΑ-2&gt;   Ο χρήστης πρέπει να μπορεί να λαμβάνει προγράμματα γυμναστικής και πρόγραμμα διατροφής βασισμένα σε προσωπικές πληροφορίες.  # noqa: E501

    :param user_id: The user&#x27;s ID
    :type user_id: int

    :rtype: DietProgram
    """
    return 'do some magic!'
