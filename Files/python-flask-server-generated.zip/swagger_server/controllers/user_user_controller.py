import connexion
import six

from swagger_server.models.user import User  # noqa: E501
from swagger_server import util


def add_user_details(user_id, birthday, gender, height, weight, level, goal, username=None, meal=None, allergies=None, restrictions=None):  # noqa: E501
    """Add details to user&#x27;s profile

    &lt;ΛΑ-10&gt;   Ο χρήστης πρέπει να μπορεί να προσθέτει προσωπικές πληροφορίες στο προφίλ του   # noqa: E501

    :param user_id: The user&#x27;s ID
    :type user_id: int
    :param birthday: The user&#x27;s birthday
    :type birthday: str
    :param gender: The user&#x27;s gender
    :type gender: str
    :param height: The user&#x27;s height
    :type height: float
    :param weight: The user&#x27;s weight
    :type weight: float
    :param level: The user&#x27;s workout level
    :type level: str
    :param goal: The user&#x27;s fitness goal
    :type goal: str
    :param username: The user&#x27;s username
    :type username: str
    :param meal: The user&#x27;s meal preferences
    :type meal: str
    :param allergies: The user&#x27;s allergies
    :type allergies: str
    :param restrictions: The user&#x27;s dietary restrictions
    :type restrictions: str

    :rtype: User
    """
    birthday = util.deserialize_datetime(birthday)
    return 'do some magic!'


def edit_user_details(user_id, height, weight, level, goal, meal=None, allergies=None, restrictions=None):  # noqa: E501
    """Edit details to user&#x27;s profile

    &lt;ΛΑ-11&gt;   Ο χρήστης πρέπει να μπορεί να επεξεργάζεται τις προσωπικές πληροφορίες στο προφίλ του.  # noqa: E501

    :param user_id: The user&#x27;s ID
    :type user_id: int
    :param height: The user&#x27;s height
    :type height: float
    :param weight: The user&#x27;s weight
    :type weight: float
    :param level: The user&#x27;s workout level
    :type level: str
    :param goal: The user&#x27;s fitness goal
    :type goal: str
    :param meal: The user&#x27;s meal preferences
    :type meal: str
    :param allergies: The user&#x27;s allergies
    :type allergies: str
    :param restrictions: The user&#x27;s dietary restrictions
    :type restrictions: str

    :rtype: User
    """
    return 'do some magic!'


def get_user_details(user_id):  # noqa: E501
    """Get a user&#x27;s details

    &lt;ΛΑ-11&gt;   Ο χρήστης πρέπει να μπορεί να επεξεργάζεται τις προσωπικές πληροφορίες στο προφίλ του.  # noqa: E501

    :param user_id: The user&#x27;s ID
    :type user_id: int

    :rtype: User
    """
    return 'do some magic!'
