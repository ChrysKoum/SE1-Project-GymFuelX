import connexion
import six

from swagger_server.models.exercise import Exercise  # noqa: E501
from swagger_server import util


def get_excercise(user_id, excercise_id):  # noqa: E501
    """Get a specific excercise&#x27;s details

    &lt;ΛΑ-4&gt;   Ο χρήστης θα πρέπει να μπορεί να δει πληροφορίες για κάθε άσκηση γυμναστικής   # noqa: E501

    :param user_id: The user&#x27;s ID
    :type user_id: int
    :param excercise_id: The ID of the excercise
    :type excercise_id: int

    :rtype: Exercise
    """
    return 'do some magic!'
