# coding: utf-8

# flake8: noqa
from __future__ import absolute_import
# import models into model package
from swagger_server.models.all_recipe import AllRecipe
from swagger_server.models.all_report import AllReport
from swagger_server.models.diet_program import DietProgram
from swagger_server.models.exercise import Exercise
from swagger_server.models.gym_program import GymProgram
from swagger_server.models.recipe import Recipe
from swagger_server.models.report import Report
from swagger_server.models.user import User
