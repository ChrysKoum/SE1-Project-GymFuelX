# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.all_report import AllReport  # noqa: E501
from swagger_server.models.report import Report  # noqa: E501
from swagger_server.test import BaseTestCase


class TestReportNutritionistController(BaseTestCase):
    """ReportNutritionistController integration test stubs"""

    def test_delete_recipe_report(self):
        """Test case for delete_recipe_report

        delete recipe report
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/report/{reportID}'.format(nutritionist_id=56, report_id=56),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_recipe_report(self):
        """Test case for get_recipe_report

        Get recipe report
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/report/{reportID}'.format(nutritionist_id=56, report_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_recipe_reports(self):
        """Test case for get_recipe_reports

        Get recipe reports
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/report'.format(nutritionist_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_recipe_report(self):
        """Test case for update_recipe_report

        Update/Correct recipe report
        """
        query_string = [('day_diet_program_ids', List[int]())]
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/report/{reportID}'.format(nutritionist_id=56, report_id=56),
            method='PUT',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
