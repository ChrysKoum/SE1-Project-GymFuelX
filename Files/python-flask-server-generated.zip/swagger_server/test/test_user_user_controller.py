# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.user import User  # noqa: E501
from swagger_server.test import BaseTestCase


class TestUserUserController(BaseTestCase):
    """UserUserController integration test stubs"""

    def test_add_user_details(self):
        """Test case for add_user_details

        Add details to user's profile
        """
        query_string = [('username', 'username_example'),
                        ('birthday', '2013-10-20T19:20:30+01:00'),
                        ('gender', 'gender_example'),
                        ('height', 1.2),
                        ('weight', 1.2),
                        ('meal', 'meal_example'),
                        ('allergies', 'allergies_example'),
                        ('restrictions', 'restrictions_example'),
                        ('level', 'level_example'),
                        ('goal', 'goal_example')]
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}'.format(user_id=56),
            method='POST',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_edit_user_details(self):
        """Test case for edit_user_details

        Edit details to user's profile
        """
        query_string = [('height', 1.2),
                        ('weight', 1.2),
                        ('meal', 'meal_example'),
                        ('allergies', 'allergies_example'),
                        ('restrictions', 'restrictions_example'),
                        ('level', 'level_example'),
                        ('goal', 'goal_example')]
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}'.format(user_id=56),
            method='PUT',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_user_details(self):
        """Test case for get_user_details

        Get a user's details
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}'.format(user_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
