# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.recipe import Recipe  # noqa: E501
from swagger_server.test import BaseTestCase


class TestRecipeNutritionistController(BaseTestCase):
    """RecipeNutritionistController integration test stubs"""

    def test_add_recipe(self):
        """Test case for add_recipe

        Add a new recipe
        """
        query_string = [('recipe_type', 'recipe_type_example'),
                        ('img_recipe', 'img_recipe_example'),
                        ('instructions', 'instructions_example'),
                        ('ingredients_name', 'ingredients_name_example'),
                        ('nutritional_table', 'nutritional_table_example'),
                        ('ingredients_quantity', 'ingredients_quantity_example'),
                        ('time', 56),
                        ('difficulty', 'difficulty_example'),
                        ('servings', 'servings_example')]
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/recipe'.format(nutritionist_id=56),
            method='POST',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_delete_recipe(self):
        """Test case for delete_recipe

        Delete recipe
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/recipe/{recipeID}'.format(nutritionist_id=56, recipe_id=56),
            method='DELETE')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_recipe_nutrionist(self):
        """Test case for get_recipe_nutrionist

        Get recipe
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/recipe/{recipeID}'.format(nutritionist_id=56, recipe_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_update_recipe_nutritionist(self):
        """Test case for update_recipe_nutritionist

        Update/Correct recipe
        """
        query_string = [('recipe_type', 'recipe_type_example'),
                        ('img_recipe', 'img_recipe_example'),
                        ('instructions', 'instructions_example'),
                        ('ingredients_name', 'ingredients_name_example'),
                        ('nutritional_table', 'nutritional_table_example'),
                        ('ingredients_quantity', 'ingredients_quantity_example'),
                        ('time', 56),
                        ('difficulty', 'difficulty_example'),
                        ('servings', 'servings_example')]
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/nutritionist/{NutritionistID}/recipe/{recipeID}'.format(nutritionist_id=56, recipe_id=56),
            method='PUT',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
