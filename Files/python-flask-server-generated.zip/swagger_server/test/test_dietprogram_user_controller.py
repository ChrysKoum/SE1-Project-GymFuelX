# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.diet_program import DietProgram  # noqa: E501
from swagger_server.test import BaseTestCase


class TestDietprogramUserController(BaseTestCase):
    """DietprogramUserController integration test stubs"""

    def test_get_diet_program(self):
        """Test case for get_diet_program

        Get user's diet program
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}/dietprogram'.format(user_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
