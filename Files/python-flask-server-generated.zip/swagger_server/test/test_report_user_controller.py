# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestReportUserController(BaseTestCase):
    """ReportUserController integration test stubs"""

    def test_create_diet_report(self):
        """Test case for create_diet_report

        Create a report to this recipe
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}/recipe/{recipeID}'.format(user_id=56, recipe_id=56),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_create_gym_report(self):
        """Test case for create_gym_report

        Create a report to this gymprogram
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}/gymprogram'.format(user_id=56),
            method='POST')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
