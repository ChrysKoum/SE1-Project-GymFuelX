# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.models.all_recipe import AllRecipe  # noqa: E501
from swagger_server.models.recipe import Recipe  # noqa: E501
from swagger_server.test import BaseTestCase


class TestRecipeUserController(BaseTestCase):
    """RecipeUserController integration test stubs"""

    def test_get_all_recipies(self):
        """Test case for get_all_recipies

        Get the list of all the Recipies
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}/recipe'.format(user_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_recipe(self):
        """Test case for get_recipe

        Get a specific recipe's details
        """
        response = self.client.open(
            '/DIMOSKOMPITSELIDIS/Team27/2.0.0/user/{userID}/recipe/{recipeID}'.format(user_id=56, recipe_id=56),
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
